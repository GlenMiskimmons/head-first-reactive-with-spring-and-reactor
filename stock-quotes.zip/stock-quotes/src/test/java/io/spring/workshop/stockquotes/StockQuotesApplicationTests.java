package io.spring.workshop.stockquotes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockQuotesApplicationTests {

	@Test
	void contextLoads() {
	}

}
